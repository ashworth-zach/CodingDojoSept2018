var home = require('../controllers/home.js');

module.exports = function(app){

	app.get('/', function(req, res) {
        home.get(req,res);
    });
    app.get('/:id', function(req, res) {
        home.getone(req,res);
    });
    app.post('/', function(req, res) {
        home.create(req,res);
    });
    app.patch('/:id', function(req, res) {
        home.patch(req,res);
    });
    app.delete('/:id', function(req, res) {
        home.delete(req,res);
    });

}