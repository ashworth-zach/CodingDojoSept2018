var express = require('express');
var bodyParser = require('body-parser');
var queryString = require('querystring');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/static'));
app.use(bodyParser.urlencoded({
    extended: true
}));

app.get('/', function (req, res) {
    res.render('index');
});

var count = 0;
io.on('connection', function (socket) {
    console.log("Welcome");
    socket.on('blue', function () {
        socket.broadcast.emit("color", {
            color:"blue"
        })
        socket.emit("color", {
            color:"blue"
        })
        
    });
    socket.on('red', function () {
        socket.broadcast.emit("color", {
            color:"red"
        })
        socket.emit("color", {
            color:"red"
        })
        
    });
    socket.on('yellow', function () {
        socket.broadcast.emit("color", {
            color:"yellow"
        })
        socket.emit("color", {
            color:"yellow"
        })
        
    });
});

server.listen('8000', function () {
    console.log("Listening on port 8000.");
});