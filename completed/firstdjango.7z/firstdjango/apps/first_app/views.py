from django.shortcuts import render, HttpResponse, redirect
  # the index function is called when root is visited
def index(request):
    response = "no mysql query knowledge with django so just pretend this is a list of blogs!"
    return HttpResponse(response)
def new(request):
    #render('new.html')
    return HttpResponse("render('newform.html)")
def create(request):
    return redirect('/')
def show(request, number):
    print(number)
    return HttpResponse(number)
def edit(request,number):
    return HttpResponse('requesting to edit blog #: '+number)
def destroy(request,number):
    print(number)
    return redirect('/')