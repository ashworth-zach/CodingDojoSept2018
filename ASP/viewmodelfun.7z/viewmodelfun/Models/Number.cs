namespace viewmodelfun.Models
{
    public class Number
    {
        public int[] list {get;set;}
        public Number(int[] nums){
            list= nums;
            
        }
    }
}