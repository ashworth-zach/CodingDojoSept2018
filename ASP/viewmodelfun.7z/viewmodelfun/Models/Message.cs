namespace viewmodelfun.Models
{
    public class Message
    {
        public string content {get;set;}
        public Message(string str){
            content=str;
        }
    }
}