using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using formsubmit.Models;

namespace formsubmit.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        public IActionResult Index()
        {
            return View("index");
        }
        [HttpPost("create")]
        public IActionResult Create(string firstname, string lastname, string email, string password, int age)
        {
            Form user = new Form(firstname, lastname, email, password, age);

            TryValidateModel(user);

            if (ModelState.IsValid)
            {
                return RedirectToAction("success");
            }
            else
            {
                return View("index");
            }
        }
        [HttpGet("success")]
        public IActionResult Success()
        {
            return View("success");
        }
    }
}
