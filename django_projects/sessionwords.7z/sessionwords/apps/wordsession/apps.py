from django.apps import AppConfig


class WordsessionConfig(AppConfig):
    name = 'wordsession'
