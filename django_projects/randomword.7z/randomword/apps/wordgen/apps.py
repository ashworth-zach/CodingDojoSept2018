from django.apps import AppConfig


class WordgenConfig(AppConfig):
    name = 'wordgen'
