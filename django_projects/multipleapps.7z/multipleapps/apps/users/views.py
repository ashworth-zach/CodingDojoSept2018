from django.shortcuts import render, redirect, HttpResponse

def register(request):
    return HttpResponse('placeholder for new user record')
def login(request):
    return HttpResponse('placeholder to login')
def show(request):
    return HttpResponse('placeholder to show users')