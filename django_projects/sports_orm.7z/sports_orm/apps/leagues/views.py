from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Q
from . import team_maker

def index(request):
	context = {
		"baseballleagues": League.objects.all().values().filter(sport='Baseball'),
		'womensleagues': League.objects.all().values().filter(name__contains='women'),
		'hockeyleagues':League.objects.all().values().filter(sport__contains='hockey'),
		'notfootball':League.objects.all().values().exclude(name__contains='football'),
		'conferences':League.objects.all().values().filter(name__contains='conference'),
		'atlanticleagues':League.objects.all().values().filter(name__contains='atlantic'),
		'dallasteams':Team.objects.all().values().filter(location__contains='dallas'),
		'raptors':Team.objects.all().values().filter(team_name__contains='raptors'),
		'cityteams':Team.objects.all().values().filter(location__contains='city'),
		'beginwitht':Team.objects.all().values().filter(team_name__startswith='t'),
		'alphateams':Team.objects.all().values().order_by('location'),
		'alphaname':Team.objects.all().values().order_by('team_name'),
		'cooperplayer':Player.objects.all().values().filter(last_name__contains='cooper'),
		'joshuas':Player.objects.all().values().filter(first_name__contains='joshua'),
		'notjoshuas':Player.objects.all().values().filter(last_name__contains='cooper').exclude(first_name__contains='joshua'),
		'alexwyatt':Player.objects.all().values().filter(Q(first_name__contains='wyatt')|Q(first_name__contains='alexander'))



	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")