from django.apps import AppConfig


class ShowtimeConfig(AppConfig):
    name = 'showtime'
